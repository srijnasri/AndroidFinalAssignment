package codepath.apps.demointroandroid;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

class ImplicitIntentsActivity :Activity() {

	public override fun onCreate(savedInstanceState:Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_implicit_intents)
	}


	public override fun onCreateOptionsMenu(menu:Menu):Boolean {
		// Inflate the menu; this adds items to the action bar if it is present.
		menuInflater.inflate(R.menu.activity_implicit_intents, menu)
		return true
	}
	
	public fun visitUrlAddress(v:View ) {
		val url:Uri  = getUriToVisit()
		if (url != null) {
			val i:Intent = Intent(Intent.ACTION_VIEW)
			i.data = url
			startActivity(i);
		}
			
	}
	
	public fun getUriToVisit():Uri {
		var urlAddress:String  =  ( findViewById<TextView>(R.id.txtUrlAddress)).getText().toString()
		if (urlAddress != null) {
		  if (!urlAddress.startsWith("http://"))
		     urlAddress = "http://" + urlAddress
		  Uri.parse(urlAddress)
		} else {
		  null
		}
	}

}
