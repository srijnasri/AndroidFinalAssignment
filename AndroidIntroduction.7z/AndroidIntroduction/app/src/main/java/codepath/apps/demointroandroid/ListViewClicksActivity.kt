package codepath.apps.demointroandroid;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

class ListViewClicksActivity :Activity() {
	var adapter:ArrayAdapter<String> = TODO()


	protected override fun onCreate(savedInstanceState:Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_list_view_clicks)
		val myCountries : Array<String> = arrayOf<String>("United States", "Canada", "Mexico", "Japan" )
		adapter = ArrayAdapter<String>(this,
		  android.R.layout.simple_list_item_1, myCountries);

		val listView:ListView = findViewById<ListView>(R.id.lvDemo)
		listView.setAdapter(adapter);
		listView.onItemClickListener = new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, val view:View,val position:Int, val id:Long) {
			String country = adapter.getItem(position);
			SimpleAlertDialog.displayWithOK(ListViewClicksActivity.this, country);
			Toast.makeText(ListViewClicksActivity.this, country, Toast.LENGTH_SHORT).show();
		}

		};
	}


	public override fun onCreateOptionsMenu(menu:Menu):Boolean {
		// Inflate the menu; this adds items to the action bar if it is present.
		menuInflater.inflate(R.menu.activity_list_view_clicks, menu)
		return true;
	}

}
